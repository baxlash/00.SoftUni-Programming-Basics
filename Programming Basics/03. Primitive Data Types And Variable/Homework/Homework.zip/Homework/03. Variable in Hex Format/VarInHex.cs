﻿using System;

class VarInHex
{
    static void Main()
    {
        int hex = 0xFE;
        Console.WriteLine(hex);
    }
}
