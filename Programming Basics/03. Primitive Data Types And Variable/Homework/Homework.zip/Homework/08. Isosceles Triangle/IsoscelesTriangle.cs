﻿using System;

class IsoscelesTriangle
{
    static void Main()
    {
        char copyRight = '\u00a9';

        Console.WriteLine("   "+copyRight);
        Console.WriteLine("  "+copyRight+" "+copyRight);
        Console.WriteLine(" "+copyRight+"   "+copyRight);
        Console.WriteLine(copyRight+" "+copyRight+" "+copyRight+" "+copyRight);
    }
}
