﻿using System;

class StringsAndObjects
{
    static void Main()
    {
        String str1 = "Hello";
        String str2 = "World";
        Object obj1 = str1 + " " + str2;
        String str3 = (String)obj1; 

    }
}
