﻿using System;

class EmployeeData
{
    static void Main()
    {
        String firstName = "Amanda";
        String lastName = "Jason";
        byte age = 27;
        char gender = 'f';
        long personalID = 8306112507;
        int employeeID = 27563571;

        Console.WriteLine("First Name: {0}\nLast Name: {1}\nAge: {2}\nGender: {3}\nPersonal ID: {4}\nEmployee ID: {5}", firstName, lastName, age, gender, personalID, employeeID);
    }
}
