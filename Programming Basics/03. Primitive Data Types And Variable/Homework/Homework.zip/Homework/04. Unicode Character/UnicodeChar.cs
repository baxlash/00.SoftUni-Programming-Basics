﻿using System;

class UnicodeChar
{
    static void Main()
    {
        char char1 = '\u002A';
        Console.WriteLine(char1);
    }
}
