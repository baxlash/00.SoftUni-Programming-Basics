﻿using System;

class FloatOrDouble
{
    static void Main()
    {
        double var1 = 34.567839023d;
        float var2 = 12.345f;
        double var3 = 8923.1234857d;
        float var4 = 3456.091f;
    }
}
