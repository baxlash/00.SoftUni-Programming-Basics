﻿using System;

class PrintYourName
{
    static void Main()
    {
        Console.WriteLine("My name is Yaro.");
    }
}
