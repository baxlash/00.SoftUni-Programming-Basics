﻿using System;

class PrintFirstAndLastName
{
    static void Main()
    {
        Console.WriteLine("Yaroslav");
        Console.WriteLine("Dimitrov");
    }
}
