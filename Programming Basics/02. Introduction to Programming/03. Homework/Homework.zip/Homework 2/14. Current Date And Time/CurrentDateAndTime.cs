﻿using System;

class CurrentDateAndTime
{
    static void Main()
    {
        Console.WriteLine(DateTime.Now.ToString());
    }
}
