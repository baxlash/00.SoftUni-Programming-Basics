using System;

class IsThirdDigit7
{
	public static void Main ()
	{
		Console.Write ("Enter a number: ");
		int number = int.Parse (Console.ReadLine ());

		int shifted = number / 100;
		bool result = shifted % 7 == 0;

		Console.WriteLine ("{0} third digit 7? {1}", number, result);
	}
}