using System;

class MoonGravity
{
	public static void Main ()
	{
		Console.Write ("Enter your weight in kg: ");
		double weight = double.Parse (Console.ReadLine ());

		double weightOnMoon = weight * 0.17;

		Console.WriteLine ("On the moon you will weight {0:F3}kg.", weightOnMoon);
	}
}
