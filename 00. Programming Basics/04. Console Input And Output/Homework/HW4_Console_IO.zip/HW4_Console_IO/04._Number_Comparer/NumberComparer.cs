using System;

class NumberComparer
{
	public static void Main ()
	{
		double numberOne;
		double numberTwo;

		Console.Write ("Enter the first number: ");
		numberOne = double.Parse (Console.ReadLine ());
		Console.Write ("Enter the second number: ");
		numberTwo = double.Parse (Console.ReadLine ());

		Console.WriteLine ("The greater number between {0:F2} and {1:F2} is {2:F2}.", numberOne, numberTwo, Math.Max (numberOne, numberTwo));
	}
}
