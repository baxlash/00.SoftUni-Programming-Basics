using System;

namespace _Numbers_from_1_to_n
{
	class SumNumberFrom1ToN
	{
		public static void Main ()
		{
			Console.Write ("Enter a number: ");
			int number = int.Parse (Console.ReadLine ());
			int result = 0;

			for (int i = number; i >= 0; i--)
			{
				result += i;
			}

			Console.WriteLine ("The sum of the numbers between 1 and {0} is {1}.", number, result);
		}
	}
}
